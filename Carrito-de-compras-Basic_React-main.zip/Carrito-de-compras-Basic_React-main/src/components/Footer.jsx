import { useState } from 'react';
import './css/slider.css';
import './css/style.css';
import './assets/css/estilos.css';
import logo_capsulitas from './images/CAPSULITAS (1).png';
import facebook from './images/social/facebook.png';
import instagram from './images/social/instagram.png';
import whatsapp from './images/social/whatsapp.png';
import youtube from './images/social/youtube.png';

export const Footer = ({
	allProducts,
	setAllProducts,
	total,
	countProducts,
	setCountProducts,
	setTotal,
}) => {
	return (
        <footer>
        <div class="container__footer">
          <div class="box__footer">
            <div class="logo">
              <img src={logo_capsulitas} alt=""/>
            </div>
          </div>
          <div class="box__footer">
            <h2>FARMACIA CAPSULITAS</h2>
            <a href="index.php">Inicio</a>
            <a href="productos.php">Productos</a>
            <a href="contactos.php">Contactos</a>
            <a href="nosotros.php">Sobre nosostros</a>
          </div>
  
      <div class="box__footer">
      <h2>REDES SOCIALES</h2>
          <a href="#"><img src={facebook} alt=""/>Facebook</a>
          <a href="#"><img src={whatsapp} alt=""/> Whatsapp</a>
          <a href="#"><img src={youtube} alt=""/> Youtube</a>
          <a href="#"><img src={instagram} alt=""/> Instagram</a>            
      </div>
  </div>
  
  <div class="box__copyright">
      <p>FARMACIA CAPSULITAS <b>Univ. Daniel Elio Paredes Rivera</b></p>
      <a href="https://www.mediafire.com/file/7wddkvbg4n3dgf2/LICENCIA_MIT.docx/file" target="_blank">
                 <b>LICENCIA MIT</b>   
                </a>
                <a href="https://www.mediafire.com/file/7wddkvbg4n3dgf2/LICENCIA_MIT.docx/file" target="_blank">
                 <b>MI CODIGO EN GITHUB</b>   
                </a>
  </div>
  
  
  </footer>
	);
};
