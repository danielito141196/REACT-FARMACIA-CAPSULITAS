import { useState } from 'react';
import './css/slider.css';
import './css/style.css';
import './assets/css/estilos.css';
import logo_capsulitas from './images/CAPSULITAS (1).png';
import facebook from './images/social/facebook.png';
import instagram from './images/social/instagram.png';
import twiter from './images/social/twitter.png';
import whatsapp from './images/social/whatsapp.png';
import youtube from './images/social/youtube.png';
import carrito from './images/carrito-de-supermercado.png';

export const Header = ({
	allProducts,
	setAllProducts,
	total,
	countProducts,
	setCountProducts,
	setTotal,
}) => {
	const [active, setActive] = useState(false);

	const onDeleteProduct = product => {
		const results = allProducts.filter(
			item => item.id !== product.id
		);

		setTotal(total - product.price * product.quantity);
		setCountProducts(countProducts - product.quantity);
		setAllProducts(results);
	};

	const onCleanCart = () => {
		setAllProducts([]);
		setTotal(0);
		setCountProducts(0);
	};

	return (
		<header>
<div class="header_superior">
            <div class="logo"><a href="#">
                <img src={logo_capsulitas} alt=""/>

                </a>
            </div>
            <div class="socialMedia">
                <a href="#">
                    <img src={facebook} alt=""/>
                </a>
                <a href="#">
                    <img src={instagram} alt=""/>
                </a>
                <a href="#">
                    <img src={twiter} alt=""/>
                </a>
                <a href="https://wa.link/80fto7" target="_blank">
                    <img src={whatsapp} alt=""/>
                </a>
                <a href="https://www.youtube.com/channel/UCKdV7jMqrq927HPpdssZFwg" target="_blank">
                    <img src={youtube} alt=""/>
                </a>
            </div>
        </div>
        <div class="container_menu">
            <div class="menu">
                <nav>
                    <ul>
                        <li><a href="/" id="select"></a></li>
                        <li><a href="/productos">Productos</a>
                            <ul>
                                <li><a>Dolores</a></li>
								<li><a>Vitaminas</a></li>
								<li><a>Lactancia</a></li>
								<li><a>Salud Digestiva</a></li>
								<li><a>Salud Respiratoria</a></li>
                            </ul>
                        </li>
                        <li><a href="/contactos">Contactos</a></li>
                        <li><a href="nosotros.">Sobre Nosotros</a></li>
                        <li>
						<div className='container-icon'>
				<div className='container-cart-icon' onClick={() => setActive(!active)}>
					<svg
						xmlns='http://www.w3.org/2000/svg'
						fill='none'
						viewBox='0 0 24 24'
						strokeWidth='1.5'
						stroke='currentColor'
						className='icon-cart'
					>
						<image
						    href={carrito}
							x='0'
							y='0'
							width='24'
							height='24'
						/>
					</svg>
					<div className='count-products'>
						<span id='contador-productos'>{countProducts}</span>
					</div>
				</div>

				<div
					className={`container-cart-products ${
						active ? '' : 'hidden-cart'
					}`}
				>
					{allProducts.length ? (
						<>
							<div className='row-product'>
								{allProducts.map(product => (
									<div className='cart-product' key={product.id}>
										<div className='info-cart-product'>
											<span className='cantidad-producto-carrito'>
												{product.quantity}
											</span>&nbsp;&nbsp;
											<p className='titulo-producto-carrito'>
												{product.nameProduct}
											</p>
											<span className='precio-producto-carrito'>
												${product.price}
											</span>
										</div>
										<svg
											xmlns='http://www.w3.org/2000/svg'
											fill='none'
											viewBox='0 0 24 24'
											strokeWidth='1.5'
											stroke='currentColor'
											className='icon-close'
											onClick={() => onDeleteProduct(product)}
										>
											<path
												strokeLinecap='round'
												strokeLinejoin='round'
												d='M6 18L18 6M6 6l12 12'
											/>
										</svg>
									</div>
								))}
							</div>

							<div className='cart-total'>
								<h3>TOTAL A PAGAR:</h3>
								<span className='total-pagar'>${total}</span>
							</div>
							<button className='btn-pagar' onClick={onCleanCart}>
								IR A PAGAR
							</button>
							<button className='btn-clear-all' onClick={onCleanCart}>
								VACIAR CARRITO
							</button>
							
						</>
					) : (
						<p className='cart-empty'>EL CARRITO ESTÁ VACÍO</p>
					)}
				</div>
			</div>
						</li>
                    </ul>
                </nav>
            </div>
        </div>

		</header>

	);
};
