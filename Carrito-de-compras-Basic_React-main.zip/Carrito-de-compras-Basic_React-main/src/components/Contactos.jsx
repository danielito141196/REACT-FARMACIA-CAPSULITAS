import { useState } from 'react';
import Whatsapp from './images/social/whatsapp.png';
export const contactos = ({
	allProducts,
	setAllProducts,
	countProducts,
	setCountProducts,
	total,
	setTotal,
})

	return (
        <body>
        <h1>CONTACTOS</h1>
        <div class="container">                        
        <form method="POST" onsubmit="return mostrarMensaje()">
        <div class="container_formulario">
            <div class="form-group">
                <label for="nombre">Nombre:</label>
                <input type="text" id="nombre" name="nombre" required/>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required/>
            </div>
            <div class="form-group">
                <label for="telefono">Número de teléfono (Bolivia):</label>
                <input type="text" id="telefono" name="telefono" required pattern="^\{8}$" title="Por favor, ingresa un número de teléfono válido de Bolivia que comience con 6 o 7 y tenga 8 dígitos después de +591"/>
            </div>
            <div class="form-group">
                <label for="mensaje">Mensaje:</label>
                <textarea id="mensaje" name="mensaje" rows="4" required></textarea>
            </div>
            <button type="submit">ENVIAR</button>
        </div>
        </form>
        
        <div id="mensajeEmergente" class="mensaje-oculto">
        <span id="cerrarMensaje" class="cerrar">&times;</span>
            <p>SUS DATOS FUERON ENVIADOS CORRECTAMENTE, EN BREVE NOS COMUNICAREMOS CON USTED.</p>
        </div>
        <script src="script.js"></script>
        <div class="maps">   
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3795.189420358136!2d-67.10290512484683!3d-17.969922180277454!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x93e2b1f469b6167d%3A0x6e9b76050d1da4ae!2sFarmacia%20Santa%20Rita!5e0!3m2!1ses!2sbo!4v1698777489087!5m2!1ses!2sbo" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div></div>
        <div class="btn-flotante"><a href="https://wa.link/80fto7" target="_blank"><img  src={whatsap} alt=""/></a></div>
        </body> 
            );
;
